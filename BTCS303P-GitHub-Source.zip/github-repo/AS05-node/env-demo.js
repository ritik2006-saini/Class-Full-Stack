const http = require("http");
const port = Number(process.env.PORT) || 4000;
const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
  res.end(`Environment-variable server is listening on port ${port}.`);
});
server.listen(port, () => console.log(`Server listening on port ${port}`));
