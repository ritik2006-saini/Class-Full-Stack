const sum = require("./sum");
const evenOdd = require("./even-odd");
console.log("Sum of 12 and 7:", sum(12, 7));
console.log("12 is", evenOdd(12));
console.log("7 is", evenOdd(7));
