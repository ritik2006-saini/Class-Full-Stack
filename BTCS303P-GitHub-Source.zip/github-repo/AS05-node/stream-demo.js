const fs = require("fs");
const fileName = "large-file.txt";
const lines = Array.from({ length: 60 }, (_, index) => `Line ${index + 1}: Node.js stream demonstration.`);
fs.writeFileSync(fileName, `${lines.join("\n")}\n`, "utf8");
let chunks = 0;
const stream = fs.createReadStream(fileName, { encoding: "utf8", highWaterMark: 64 });
stream.on("data", (chunk) => {
  chunks += 1;
  console.log(`Chunk ${chunks}: ${Buffer.byteLength(chunk, "utf8")} bytes`);
});
stream.on("end", () => console.log(`Finished reading ${fileName} in ${chunks} chunks.`));
stream.on("error", (error) => console.error("Stream error:", error.message));
