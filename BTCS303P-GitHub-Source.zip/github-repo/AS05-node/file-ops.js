const fs = require("fs");
const source = "student.txt";
const destination = "profile.txt";
const profile = "Name: Your Name\nRoll Number: YOUR_ROLL_NUMBER\n";
fs.writeFile(source, profile, (err) => {
  if (err) return console.error("Write failed:", err.message);
  fs.appendFile(source, "Course: Full Stack Web Development\n", (err2) => {
    if (err2) return console.error("Append failed:", err2.message);
    fs.readFile(source, "utf8", (err3, content) => {
      if (err3) return console.error("Read failed:", err3.message);
      console.log("File content:\n" + content);
      fs.rename(source, destination, (err4) => {
        if (err4) return console.error("Rename failed:", err4.message);
        console.log(`${source} renamed to ${destination}`);
      });
    });
  });
});
