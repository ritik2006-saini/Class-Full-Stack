const fs = require("fs");
const directory = "uploads";
fs.mkdir(directory, { recursive: true }, (err) => {
  if (err) throw err;
  const files = ["file1.txt", "file2.txt", "file3.txt"];
  files.forEach((name) => fs.writeFileSync(`${directory}/${name}`, ""));
  fs.readdir(directory, (readError, names) => {
    if (readError) throw readError;
    console.log("Files before deletion:", names.join(", "));
    fs.unlink(`${directory}/file3.txt`, (deleteError) => {
      if (deleteError) throw deleteError;
      console.log("Deleted uploads/file3.txt");
    });
  });
});
