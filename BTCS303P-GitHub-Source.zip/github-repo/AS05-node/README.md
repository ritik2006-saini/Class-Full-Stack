# AS05 Node.js Lab

Run `npm install` once. Files use CommonJS and Node.js built-in modules; `id-gen.js` also requires nanoid 3.

```sh
node app1.js
node file-ops.js
node dir-ops.js
node path-demo.js
node sys-report.js
node order-events.js
node server.js
node stream-demo.js
node id-gen.js
node calc-cli.js 10 5 +
node calc-cli.js 10 5 "*"
node env-demo.js
```

`file-ops.js` creates and renames `student.txt` to `profile.txt` in this folder. Replace the example name/roll number first. `dir-ops.js` creates `uploads/` and removes `uploads/file3.txt`. `server.js` listens on port 3000; `env-demo.js` defaults to 4000.
