const os = require("os");
const mib = (bytes) => `${(bytes / (1024 ** 2)).toFixed(2)} MiB`;
console.log("Platform:", os.platform());
console.log("Architecture:", os.arch());
console.log("Total memory:", mib(os.totalmem()));
console.log("Free memory:", mib(os.freemem()));
console.log("CPU cores:", os.cpus().length);
console.log("System uptime:", (os.uptime() / 60).toFixed(2), "minutes");
