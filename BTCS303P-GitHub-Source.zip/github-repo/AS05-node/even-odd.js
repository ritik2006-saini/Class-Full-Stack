function evenOdd(number) { return number % 2 === 0 ? "even" : "odd"; }
module.exports = evenOdd;
