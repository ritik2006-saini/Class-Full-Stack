const [, , aArg, bArg, operator] = process.argv;
const a = Number(aArg), b = Number(bArg);
if (aArg === undefined || bArg === undefined || !Number.isFinite(a) || !Number.isFinite(b)) {
  console.error("Usage: node calc-cli.js <number> <number> <+|-|*|/>"); process.exitCode = 1;
} else {
  let result;
  switch (operator) {
    case "+": result = a + b; break;
    case "-": result = a - b; break;
    case "*": result = a * b; break;
    case "/": if (b === 0) { console.error("Cannot divide by zero."); process.exitCode = 1; } else result = a / b; break;
    default: console.error("Operator must be +, -, *, or /."); process.exitCode = 1;
  }
  if (result !== undefined) console.log(`${a} ${operator} ${b} = ${result}`);
}
