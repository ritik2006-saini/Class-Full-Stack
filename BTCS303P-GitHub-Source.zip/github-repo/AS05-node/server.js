const http = require("http");
const { parse } = require("url");
const students = [
  { id: 1, name: "Aarav Sharma", course: "Computer Science" },
  { id: 2, name: "Diya Verma", course: "Information Technology" },
  { id: 3, name: "Kabir Singh", course: "Computer Science" },
];
const server = http.createServer((req, res) => {
  const parsed = parse(req.url, true);
  const pathname = parsed.pathname;
  if (req.method === "GET" && pathname === "/search") {
    const keyword = parsed.query.keyword || "";
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
    return res.end(JSON.stringify({ keyword, message: `Search keyword: ${keyword}` }));
  }
  if (req.method === "GET" && pathname === "/") {
    res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
    return res.end("Welcome to the Node.js student API!");
  }
  if (req.method === "GET" && pathname === "/students") {
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
    return res.end(JSON.stringify(students));
  }
  const match = pathname.match(/^\/students\/(\d+)$/);
  if (req.method === "GET" && match) {
    const student = students.find((entry) => entry.id === Number(match[1]));
    res.writeHead(student ? 200 : 404, { "Content-Type": "application/json; charset=utf-8" });
    return res.end(JSON.stringify(student || { error: "Student not found" }));
  }
  res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
  res.end("<h1>404 - Page not found</h1>");
});
server.listen(3000, () => console.log("Server running at http://localhost:3000"));
