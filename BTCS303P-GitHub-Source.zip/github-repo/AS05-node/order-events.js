const EventEmitter = require("events");
const orderEvents = new EventEmitter();
orderEvents.on("orderPlaced", ({ id, item, amount }) => {
  console.log(`Receipt | Order ${id} | ${item} | Rs. ${amount.toFixed(2)}`);
});
[
  { id: "A101", item: "Notebook", amount: 120 },
  { id: "A102", item: "Pen set", amount: 85.5 },
  { id: "A103", item: "Backpack", amount: 1499 },
].forEach((order) => orderEvents.emit("orderPlaced", order));
