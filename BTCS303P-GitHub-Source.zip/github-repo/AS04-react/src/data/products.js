const products = [
  { id: "p-101", name: "Everyday Backpack", description: "A durable daypack for work and weekends.", price: 2499, image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80" },
  { id: "p-102", name: "Classic Watch", description: "A clean, versatile watch with a steel finish.", price: 4299, image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80" },
  { id: "p-103", name: "Wireless Headphones", description: "Comfortable over-ear headphones for daily listening.", price: 3199, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80" },
  { id: "p-104", name: "Ceramic Travel Mug", description: "A reusable mug for coffee on the go.", price: 899, image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=900&q=80" },
];
export default products;
