import { useState } from "react";
import ProductList from "./components/ProductList.jsx";
import Cart from "./components/Cart.jsx";
import CheckoutForm from "./components/CheckoutForm.jsx";
import "./App.css";
export default function App() {
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  function addToCart(product) {
    setCart((current) => {
      const exists = current.find((item) => item.product.id === product.id);
      return exists
        ? current.map((item) => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...current, { product, quantity: 1 }];
    });
  }
  function removeFromCart(productId) {
    setCart((current) => current.filter((item) => item.product.id !== productId));
  }
  return <div className="app-shell">
    <header className="navbar"><a className="brand" href="#top">Everyday Store</a>
      <button className="cart-toggle" type="button" aria-expanded={isCartOpen} aria-controls="cart-panel" onClick={() => setIsCartOpen((open) => !open)}>
        {isCartOpen ? "Close cart" : "Cart"}<span className="badge">{itemCount}</span>
      </button></header>
    <main id="top" className="page-content">
      <section className="intro"><p className="eyebrow">Thoughtful everyday goods</p><h1>Find your next favorite.</h1><p>Useful essentials, selected for daily life.</p></section>
      <ProductList addToCart={addToCart} />
      {isCartOpen && <section id="cart-panel" className="panel" aria-label="Shopping cart">
        <h2>Your Cart</h2><Cart cart={cart} removeFromCart={removeFromCart} />
        <h2>Checkout Details</h2><CheckoutForm disabled={cart.length === 0} />
      </section>}
    </main><footer>BTCS303P-AS04 · React mini e-commerce demonstration</footer>
  </div>;
}
