import { useState } from "react";
const initialForm = { name: "", address: "", pincode: "", phone: "", paymentMethod: "" };
export default function CheckoutForm({ disabled }) {
  const [form, setForm] = useState(initialForm);
  const [message, setMessage] = useState("");
  const update = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  function submit(event) {
    event.preventDefault();
    setMessage(`Thank you, ${form.name}. Your details are ready for checkout.`);
  }
  return <form className="checkout-form" onSubmit={submit}>
    <label>Name<input name="name" value={form.name} onChange={update} required /></label>
    <label>Address<textarea name="address" value={form.address} onChange={update} required /></label>
    <label>Pincode<input name="pincode" value={form.pincode} onChange={update} inputMode="numeric" required /></label>
    <label>Phone<input name="phone" value={form.phone} onChange={update} type="tel" required /></label>
    <label>Payment Method<select name="paymentMethod" value={form.paymentMethod} onChange={update} required>
      <option value="" disabled>Select a method</option><option value="upi">UPI</option>
      <option value="card">Credit / debit card</option><option value="cod">Cash on delivery</option>
    </select></label>
    <button type="submit" disabled={disabled}>Continue to Checkout</button>
    {message && <p role="status">{message}</p>}
  </form>;
}
