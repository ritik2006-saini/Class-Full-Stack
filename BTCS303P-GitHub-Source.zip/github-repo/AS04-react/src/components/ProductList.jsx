import products from "../data/products.js";
import ProductCard from "./ProductCard.jsx";
export default function ProductList({ addToCart }) {
  return <section className="product-grid" aria-label="Products">
    {products.map((product) => <ProductCard key={product.id} product={product} addToCart={addToCart} />)}
  </section>;
}
