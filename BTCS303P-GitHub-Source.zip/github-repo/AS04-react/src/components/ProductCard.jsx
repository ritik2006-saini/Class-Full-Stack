function formatPrice(amount) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}
export default function ProductCard({ product, addToCart }) {
  return <article className="product-card">
    <img src={product.image} alt={product.name} loading="lazy" />
    <div className="product-card__body"><h3>{product.name}</h3><p>{product.description}</p>
      <strong>{formatPrice(product.price)}</strong>
      <button type="button" onClick={() => addToCart(product)}>Add to Cart</button>
    </div>
  </article>;
}
