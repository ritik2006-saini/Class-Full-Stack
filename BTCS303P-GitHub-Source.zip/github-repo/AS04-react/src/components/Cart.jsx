function formatPrice(amount) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}
export default function Cart({ cart, removeFromCart }) {
  const grandTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  if (cart.length === 0) return <p className="empty-cart" role="status">Your cart is empty</p>;
  return <div className="cart-content"><div className="cart-table-wrap"><table>
    <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th><th /></tr></thead>
    <tbody>{cart.map(({ product, quantity }) => <tr key={product.id}>
      <td>{product.name}</td><td>{formatPrice(product.price)}</td><td>{quantity}</td>
      <td>{formatPrice(product.price * quantity)}</td>
      <td><button className="text-button" type="button" onClick={() => removeFromCart(product.id)} aria-label={`Remove ${product.name}`}>Remove</button></td>
    </tr>)}</tbody></table></div>
    <p className="grand-total"><strong>Grand total: {formatPrice(grandTotal)}</strong></p>
  </div>;
}
