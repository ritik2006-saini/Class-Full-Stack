require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = Number(process.env.PORT) || 5000;
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  console.error("Missing API_KEY. Copy .env.example to .env and configure it.");
  process.exit(1);
}

let tasks = [
  { id: 1, title: "Read the lab sheet", completed: true },
  { id: 2, title: "Build the Express API", completed: false },
  { id: 3, title: "Add request middleware", completed: false },
  { id: 4, title: "Connect the React client", completed: false },
  { id: 5, title: "Test error handling", completed: false },
];
let nextId = 6;

// Development-only open CORS for the lab clients. Restrict origins before deployment.
app.use(cors());
app.use(express.json());
app.use((req, res, next) => {
  console.log(`${req.method} ${req.originalUrl} ${new Date().toISOString()}`);
  next();
});
function requireApiKey(req, res, next) {
  if (req.get("x-api-key") !== API_KEY) {
    return res.status(401).json({ error: { message: "Unauthorized: valid x-api-key required", status: 401 } });
  }
  next();
}
function findTask(req, res, next) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: { message: "Task id must be a positive integer", status: 400 } });
  req.taskIndex = tasks.findIndex((task) => task.id === id);
  if (req.taskIndex === -1) return res.status(404).json({ error: { message: `Task ${id} not found`, status: 404 } });
  next();
}
app.get("/api/tasks", (req, res) => res.json(tasks));
app.get("/api/tasks/:id", findTask, (req, res) => res.json(tasks[req.taskIndex]));
app.post("/api/tasks", requireApiKey, (req, res) => {
  const title = typeof req.body.title === "string" ? req.body.title.trim() : "";
  if (!title) return res.status(400).json({ error: { message: "title is required", status: 400 } });
  const task = { id: nextId++, title, completed: Boolean(req.body.completed) };
  tasks.push(task);
  res.status(201).json(task);
});
app.put("/api/tasks/:id", requireApiKey, findTask, (req, res) => {
  const title = typeof req.body.title === "string" ? req.body.title.trim() : "";
  if (!title) return res.status(400).json({ error: { message: "title is required", status: 400 } });
  tasks[req.taskIndex] = { ...tasks[req.taskIndex], title, completed: Boolean(req.body.completed) };
  res.json(tasks[req.taskIndex]);
});
app.delete("/api/tasks/:id", requireApiKey, findTask, (req, res) => {
  const [deleted] = tasks.splice(req.taskIndex, 1);
  res.json({ message: "Task deleted", task: deleted });
});
app.use((req, res) => res.status(404).json({ error: { message: `Route ${req.method} ${req.originalUrl} not found`, status: 404 } }));
app.use((err, req, res, next) => {
  console.error(err);
  const status = Number(err.status) || 500;
  res.status(status).json({ error: { message: status === 500 ? "Internal server error" : err.message, status } });
});
app.listen(PORT, () => console.log(`Task API listening at http://localhost:${PORT}`));
