import { useEffect, useState } from "react";
import axios from "axios";

const API_URL = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");
const API_KEY = import.meta.env.VITE_API_KEY || "";
const authHeaders = { "Content-Type": "application/json", "x-api-key": API_KEY };

function messageFrom(response, fallback) {
  return response?.data?.error?.message || fallback;
}

export default function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);

  async function loadTasks() {
    setLoading(true); setError("");
    try {
      if (!API_URL) throw new Error("Set VITE_API_URL in client-react/.env before starting the app.");
      const response = await fetch(`${API_URL}/api/tasks`);
      const body = await response.json();
      if (!response.ok) throw new Error(messageFrom({ data: body }, `Request failed (${response.status})`));
      setTasks(body);
    } catch (err) {
      setError(err.message || "Could not connect to the task API.");
    } finally { setLoading(false); }
  }

  useEffect(() => { loadTasks(); }, []);

  // Axios alternative to the fetch request above:
  // axios.get(`${API_URL}/api/tasks`).then(({ data }) => setTasks(data))
  //   .catch((err) => setError(err.response?.data?.error?.message || err.message))
  //   .finally(() => setLoading(false));
  // fetch requires response.json() and manual !response.ok handling; Axios parses JSON
  // automatically and rejects non-2xx responses, whose server message is err.response.data.

  async function addTask(event) {
    event.preventDefault();
    const cleanTitle = title.trim();
    if (!cleanTitle) { setError("Enter a task title first."); return; }
    setBusy(true); setError("");
    try {
      const response = await fetch(`${API_URL}/api/tasks`, {
        method: "POST", headers: authHeaders,
        body: JSON.stringify({ title: cleanTitle, completed: false }),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(messageFrom({ data: body }, `Could not add task (${response.status})`));
      setTasks((current) => [...current, body]); setTitle("");
    } catch (err) { setError(err.message || "Could not add task."); }
    finally { setBusy(false); }
  }

  async function deleteTask(id) {
    setBusy(true); setError("");
    try {
      const response = await fetch(`${API_URL}/api/tasks/${id}`, { method: "DELETE", headers: authHeaders });
      const body = await response.json();
      if (!response.ok) throw new Error(messageFrom({ data: body }, `Could not delete task (${response.status})`));
      setTasks((current) => current.filter((task) => task.id !== id));
    } catch (err) { setError(err.message || "Could not delete task."); }
    finally { setBusy(false); }
  }

  return <main className="shell">
    <header><p className="eyebrow">FULL STACK WEB DEVELOPMENT</p><h1>Task Manager</h1><p className="subtitle">Tasks from the Express REST API</p></header>
    <form className="add-form" onSubmit={addTask}>
      <label htmlFor="task-title">New task</label>
      <div className="form-row"><input id="task-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="What needs doing?" maxLength={120} />
      <button disabled={busy} type="submit">Add task</button></div>
    </form>
    <div className="feedback" role="status" aria-live="polite">
      {loading && <p>Loading tasks...</p>}{error && <p className="error">{error}</p>}
    </div>
    {!loading && !error && tasks.length === 0 && <p className="empty">No tasks yet. Add the first one above.</p>}
    {!loading && tasks.length > 0 && <ul className="task-list">{tasks.map((task) => <li className="task" key={task.id}>
      <div><span className="task-title">{task.title}</span><span className="task-meta">#{task.id} Â· {task.completed ? "Complete" : "Open"}</span></div>
      <button className="delete" type="button" disabled={busy} onClick={() => deleteTask(task.id)}>Delete</button>
    </li>)}</ul>}
    <button className="test-button" type="button" disabled={busy} onClick={() => deleteTask(9999)}>Try missing task (9999)</button>
    <p className="footnote">The missing-task button demonstrates a readable 404 response. Data is held in server memory and resets when the API restarts.</p>
  </main>;
}
