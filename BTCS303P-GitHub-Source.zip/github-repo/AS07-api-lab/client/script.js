const apiBase = document.body.dataset.apiBase.replace(/\/$/, "");
const statusNode = document.querySelector("#status");
const listNode = document.querySelector("#tasks");

async function loadTasks() {
  statusNode.textContent = "Loading...";
  listNode.replaceChildren();
  try {
    const response = await fetch(`${apiBase}/api/tasks`);
    if (!response.ok) throw new Error(`Request failed (${response.status})`);
    const tasks = await response.json();
    if (tasks.length === 0) {
      statusNode.textContent = "No tasks yet.";
      return;
    }
    statusNode.textContent = "";
    for (const task of tasks) {
      const item = document.createElement("li");
      item.textContent = `${task.title}${task.completed ? " (completed)" : ""}`;
      listNode.append(item);
    }
  } catch (error) {
    statusNode.textContent = `Could not load tasks. ${error.message}. Check that the API is running and try again.`;
  }
}
loadTasks();
