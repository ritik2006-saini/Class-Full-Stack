USE college_db;

-- Part A: DDL. Run the ALTER statements in order. A5 removes the faculty table.
CREATE TABLE faculty (
  faculty_id INT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  email VARCHAR(255) UNIQUE,
  salary DECIMAL(10,2),
  dept_id INT,
  FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);
ALTER TABLE faculty ADD COLUMN phone VARCHAR(15);
ALTER TABLE faculty RENAME COLUMN phone TO contact_no;
ALTER TABLE faculty DROP COLUMN contact_no;
DROP TABLE faculty;
-- DROP removes table structure and data; TRUNCATE removes all rows but keeps structure;
-- DELETE removes selected rows (or all rows without WHERE) but keeps the table.

-- Part B: DML. B2 omits city, so city is NULL. B4 adds five every time it runs.
INSERT INTO students (student_id,name,age,city,dept_id) VALUES (109,'Neha',20,'Roorkee',1);
INSERT INTO students (student_id,name,age,dept_id) VALUES (110,'Test Student',20,1);
SELECT city FROM students WHERE student_id=110;
UPDATE students SET city='Roorkee' WHERE student_id=105;
UPDATE enrollments SET marks=marks+5 WHERE course_id=203;
DELETE FROM students WHERE student_id IN (109,110);
-- B6 intentionally fails: uncomment only to observe chk_students_age rejection.
-- INSERT INTO students (student_id,name,age,city,dept_id) VALUES (111,'Invalid Age',15,'Roorkee',1);

-- Part C: SELECT. These outputs assume original seed data.
SELECT * FROM students;
SELECT name, city FROM students;
SELECT * FROM students WHERE city='Roorkee';
SELECT * FROM students WHERE age BETWEEN 20 AND 22;
SELECT * FROM students WHERE city IN ('Roorkee','Dehradun');
SELECT * FROM students WHERE name LIKE 'A%';
SELECT * FROM students WHERE dept_id IS NULL;
SELECT DISTINCT city FROM students;
SELECT * FROM students ORDER BY age DESC, name ASC;
SELECT * FROM students ORDER BY age DESC, name ASC LIMIT 3;
SELECT name AS `Student Name`, age AS Age FROM students;

-- Part D: aggregation.
SELECT COUNT(*) AS total_students FROM students;
SELECT AVG(marks) AS average_marks, MIN(marks) AS minimum_marks, MAX(marks) AS maximum_marks FROM enrollments;
SELECT city, COUNT(*) AS student_count FROM students GROUP BY city;
SELECT c.course_id,c.title,AVG(e.marks) AS average_marks FROM courses c LEFT JOIN enrollments e ON e.course_id=c.course_id GROUP BY c.course_id,c.title;
SELECT city,COUNT(*) AS student_count FROM students GROUP BY city HAVING COUNT(*)>1;
SELECT d.dept_name,COALESCE(SUM(c.credits),0) AS total_credits FROM departments d LEFT JOIN courses c ON c.dept_id=d.dept_id GROUP BY d.dept_id,d.dept_name;
SELECT UPPER(name) AS upper_name,LENGTH(name) AS name_length FROM students;
-- WHERE filters rows before grouping; HAVING filters aggregate groups after GROUP BY.

-- Part E: joins.
SELECT s.name,d.dept_name FROM students s INNER JOIN departments d ON d.dept_id=s.dept_id;
SELECT s.name,d.dept_name FROM students s LEFT JOIN departments d ON d.dept_id=s.dept_id;
SELECT d.dept_name,s.name FROM students s RIGHT JOIN departments d ON d.dept_id=s.dept_id ORDER BY d.dept_id,s.student_id;
SELECT s.name,c.title,e.marks FROM enrollments e JOIN students s ON s.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id;
SELECT DISTINCT s.name FROM students s JOIN enrollments e ON e.student_id=s.student_id JOIN courses c ON c.course_id=e.course_id WHERE c.title='Data Structures';
SELECT s.student_id,s.name FROM students s LEFT JOIN enrollments e ON e.student_id=s.student_id WHERE e.course_id IS NULL;
SELECT c.course_id,c.title,COUNT(e.student_id) AS enrollment_count FROM courses c LEFT JOIN enrollments e ON e.course_id=c.course_id GROUP BY c.course_id,c.title;
SELECT d.dept_name,COUNT(s.student_id) AS student_count,AVG(s.age) AS average_age FROM departments d LEFT JOIN students s ON s.dept_id=d.dept_id GROUP BY d.dept_id,d.dept_name;

-- Part F: subqueries.
SELECT student_id,name,age FROM students WHERE age>(SELECT AVG(age) FROM students);
SELECT s.name,c.title,e.marks FROM enrollments e JOIN students s ON s.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id WHERE e.marks=(SELECT MAX(marks) FROM enrollments);
SELECT c.course_id,c.title FROM courses c WHERE EXISTS (SELECT 1 FROM enrollments e WHERE e.course_id=c.course_id);
SELECT s.student_id,s.name FROM students s WHERE (SELECT COUNT(*) FROM enrollments e WHERE e.student_id=s.student_id)>2;
SELECT d.dept_name,COUNT(s.student_id) AS student_count FROM departments d LEFT JOIN students s ON s.dept_id=d.dept_id GROUP BY d.dept_id,d.dept_name HAVING COUNT(s.student_id)=(SELECT MAX(dept_count) FROM (SELECT COUNT(*) AS dept_count FROM students WHERE dept_id IS NOT NULL GROUP BY dept_id) counts_by_dept);
SELECT s.name,c.title,e.marks FROM enrollments e JOIN students s ON s.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id WHERE e.marks>(SELECT AVG(e2.marks) FROM enrollments e2 WHERE e2.course_id=e.course_id);

-- Part G: indexes, views, transactions. Tiny-table EXPLAIN may choose a table scan.
CREATE INDEX idx_students_city ON students(city);
EXPLAIN SELECT * FROM students WHERE city='Roorkee';
CREATE VIEW student_marks AS SELECT s.name AS student_name,c.title AS course_title,e.marks FROM students s JOIN enrollments e ON e.student_id=s.student_id JOIN courses c ON c.course_id=e.course_id;
SELECT student_name,course_title,marks FROM student_marks WHERE marks>80;
DROP VIEW student_marks;
DROP INDEX idx_students_city ON students;
-- Run these transaction examples separately; G6 commits the changed mark.
START TRANSACTION;
UPDATE enrollments SET marks=100 WHERE student_id=101 AND course_id=201;
ROLLBACK;
SELECT marks FROM enrollments WHERE student_id=101 AND course_id=201; -- 88
START TRANSACTION;
UPDATE enrollments SET marks=100 WHERE student_id=101 AND course_id=201;
COMMIT;
SELECT marks FROM enrollments WHERE student_id=101 AND course_id=201; -- 100

-- Part H: optional challenges (MySQL 8 window functions/CTEs).
WITH totals AS (
 SELECT s.student_id,s.name,COALESCE(SUM(e.marks),0) AS total_marks
 FROM students s LEFT JOIN enrollments e ON e.student_id=s.student_id
 GROUP BY s.student_id,s.name
)
SELECT student_id,name,total_marks,RANK() OVER (ORDER BY total_marks DESC) AS marks_rank
FROM totals ORDER BY marks_rank,name;
SELECT s.name,c.title,e.marks,CASE WHEN e.marks>=90 THEN 'A' WHEN e.marks>=75 THEN 'B' WHEN e.marks>=60 THEN 'C' ELSE 'D' END AS grade
FROM enrollments e JOIN students s ON s.student_id=e.student_id JOIN courses c ON c.course_id=e.course_id;
SELECT a.name AS student_1,b.name AS student_2,a.city FROM students a JOIN students b ON a.city=b.city AND a.student_id<b.student_id WHERE a.city IS NOT NULL;
SELECT MAX(marks) AS second_highest_marks FROM enrollments WHERE marks<(SELECT MAX(marks) FROM enrollments);
