# AS08 SQL Lab

Run `setup.sql` in MySQL 8.0.16 or newer. Then run selected statements from `solutions.sql`. The solution file includes DDL and DML that intentionally modify data or remove objects. Read the comments and run exercises against a coursework database.

The setup creates `college_db` and seeds eight students, five courses, four departments, and the provided enrollments. `solutions.sql` includes all tasks A1–H4. It is not intended to be blindly executed top to bottom because the lab asks you to observe intermediate states and error cases.

For PostgreSQL, create the database separately and connect with `\c college_db`; omit MySQL's `USE` statement. The index-drop syntax differs; see the comments and written answer.
