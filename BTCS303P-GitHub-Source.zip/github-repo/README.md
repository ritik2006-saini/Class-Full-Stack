# BTCS303P Full Stack Web Development Labs

Runnable source files for the lab assignments prepared in this repository. Each folder is independent and has its own instructions.

## Projects

| Lab | Folder | Stack |
|---|---|---|
| AS04 | `AS04-react/` | Vite + React mini e-commerce with product catalog, cart, and checkout form |
| AS05 | `AS05-node/` | Node.js modules, filesystem, paths, OS, events, HTTP, streams, npm, CLI and environment variables |
| AS07 | `AS07-api-lab/` | Express CRUD API, vanilla JavaScript client, React client, Postman collection |
| AS08 | `AS08-sql/` | MySQL setup/seed script and SQL solutions for Parts Aâ€“H |

## Requirements

- Node.js 18+ and npm for AS04, AS05, and AS07.
- MySQL 8.0.16+ for AS08 (needed for enforced `CHECK` constraints).
- A browser for the React and HTML clients; Postman is optional for AS07 API requests.

## Run AS04

```sh
cd AS04-react
npm install
npm run dev
```

## Run AS05

```sh
cd AS05-node
npm install
node app1.js
node file-ops.js
node dir-ops.js
node path-demo.js
node sys-report.js
node order-events.js
node server.js
node stream-demo.js
node id-gen.js
node calc-cli.js 10 5 +
node env-demo.js
```

The HTTP server in `server.js` uses port 3000. The separate `env-demo.js` uses port 4000 by default. Configure `PORT` before starting it if needed.

## Run AS07

Follow `AS07-api-lab/README.md`. Configure local `.env` files from the included `.env.example` templates before launching the server and React client. Never commit real `.env` files or API keys.

## Run AS08

Run `AS08-sql/setup.sql` once in MySQL Workbench or a MySQL client, then run selected statements from `AS08-sql/solutions.sql`. The solution file labels operations that change or remove schema/data; use a coursework database, not a production database. The tasks are best run independently against the supplied baseline data.

## Notes

- AS04/AS05/AS07 are standalone projects; install packages from their own folder.
- AS07 task data lives in memory and resets when the API restarts.
- AS08 statements include the intended lab exercises; some statements intentionally update or drop objects. Read each section comment before running it.
- The accompanying solved Word documents are stored alongside this `github-repo` folder in the deliverables directory.
