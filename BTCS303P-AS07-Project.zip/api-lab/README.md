# Task Manager Mini App (AS07)

Full-stack REST API and clients for BTCS303P-AS07. Requirements: Node.js 18+, npm.

## Start the API
1. `cd server`
2. `npm install`
3. Copy `.env.example` to `.env` and set a private `API_KEY` value.
4. `npm run dev`

The API listens at the port configured by `PORT` (5000 by default). The seeded tasks are stored in memory and reset when the server restarts.

## Plain JavaScript client
With the API running, open `client/index.html` in a browser. It requests the task list and shows loading, errors, or tasks.

## React client
In another terminal: `cd client-react`, `npm install`, copy `.env.example` to `.env`, then `npm run dev`. Set `VITE_API_URL` to the API origin and `VITE_API_KEY` to the same value as the server API_KEY.

## Postman
Import `postman/API Lab.postman_collection.json` and `postman/API Lab.postman_environment.json`. Select the API Lab environment. Set `apiKey` in the environment to the same key used by the server. Run requests in collection order; POST/PUT/DELETE need the key.

Never commit `.env` files. `.env.example` contains placeholders only.
